<?php
// ----INCLUDE APIS------------------------------------
include ("api/api.inc.php");

// ----PAGE GENERATION LOGIC---------------------------
function createPage($timg, $ppage, $psorganisem, $torganiseorder)
{
    // Get the Presentation Layer content
    $trank = new BLLRanking();
    $trank->ranklist = jsonLoadAllGame();

    // We need to sort the squad using our custom class-based sort function
    $porganise = "";
    if ($psorganisem == "rankno")
        $porganise = "ranksortbyno";
    else if ($psorganisem == "name")
        $porganise = "ranksortbyname";

    // Only sort the array if we have a valid function name
    if (! empty($porganise))
        typ($trank->ranklist, $porganise);

    // The pagination working out how many elements we need and
    $tnoitems = sizeof($trank->ranklist);
    $tperpage = 5;
    $tnopages = ceil($tnoitems / $tperpage);

    // Create a Pagniated Array based on the number of items and what page we want.
    $tfilterrank = appPaginateArray($trank->ranklist, $ppage, $tperpage);
    $trank->squadlist = $tfilterrank;

    // Render the HTML for our Table and our Pagination Controls
    $tranktable = renderGameTable($trank);
    $tpagination = renderPagination($_SERVER['PHP_SELF'], $tnopages, $ppage);

    // Use the Presentation Layer to build the UI Elements

    $tinfo = <<<PAGE
    		</div>
    		<div class="row">
    			<div class="panel panel-primary">
    			<div class="panel-body">
    				<h2>Top 10 Games</h2>
    				
    				<div id="squad-table">
    			    {$tranktable}
                    {$tpagination}
    		        </div>
    		    </div>
    			</div>
    		</div>
    		<div class="row">
             
    		</div>
    PAGE;

    return $tinfo;
}

// ----BUSINESS LOGIC---------------------------------
// Start up a PHP Session for this user.
session_start();
$trpage = $_REQUEST["page"] ?? 1;
$currpage = is_numeric($trpage) ? $trpage : 1;
$psorganisem = $_REQUEST["psorganisem"] ?? "";
$torganiseorder = $_REQUEST["torganiseorder"] ?? "asc";

$tpagetitle = "Game Rank";
$tpage = new MasterPage($tpagetitle);
$timg = $tpage->getPage()->getDirImages();

// Build up our Dynamic Content Items.
$tpagelead = "";
$tpagecontent = createPage($timg, $trpage, $psorganisem, $torganiseorder);
$tpagefooter = "";

// ----BUILD OUR HTML PAGE----------------------------
// Set the Three Dynamic Areas (1 and 3 have defaults)
if (! empty($tpagelead))
    $tpage->setDynamic1($tpagelead);
$tpage->setDynamic2($tpagecontent);
if (! empty($tpagefooter))
    $tpage->setDynamic3($tpagefooter);
// Return the Dynamic Page to the user.
$tpage->renderPage();
?>