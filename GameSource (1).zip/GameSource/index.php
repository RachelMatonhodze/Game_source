<?php
// ----INCLUDE APIS------------------------------------
include ("api/api.inc.php");

// ----PAGE GENERATION LOGIC---------------------------
function createPage()
{
    // Page-Specific Static Content
    $pwelco = file_get_contents("data/static/index_welcome.part.html");
    $videos = file_get_contents("data/html/videos.html");

    $tinfo = <<<PAGE
           <h1>Check out the trailers for the newly released games!</h1>
           
         {$videos}
        
       
        <td> <h3><a href="http://localhost/4122COMP/tutorials/webapps17/console.php"> Click to learn about the Nintendo Switch! >>></a></td></h3>
    PAGE;
    return $tinfo;
}

// ----BUSINESS LOGIC---------------------------------
// Start up a PHP Session for this user.
session_start();

// Build up our Dynamic Content Items.
$tpagetitle = "Home Page";
$tpagelead = "";
$tpagecontent = createPage();
$tpagefooter = "";

// ----BUILD OUR HTML PAGE----------------------------
// Create an instance of our Page class
$tpage = new MasterPage($tpagetitle);
// Set the Three Dynamic Areas (1 and 3 have defaults)
if (! empty($tpagelead))
    $tpage->setDynamic1($tpagelead);
$tpage->setDynamic2($tpagecontent);
if (! empty($tpagefooter))
    $tpage->setDynamic3($tpagefooter);
// Return the Dynamic Page to the user.
$tpage->renderPage();
?>