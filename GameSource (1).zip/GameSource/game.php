<?php
// ----INCLUDE APIS------------------------------------
include ("api/api.inc.php");

// ----PAGE GENERATION LOGIC---------------------------
function createPage($pgames)
{
    $tgameprofile = "";
    foreach ($pgames as $ts) {
        $tgameprofile .= renderGameOverview($ts);
    }
    $tcontent = <<<PAGE
          {$tgameprofile}
    PAGE;
    return $tcontent;
}

// ----BUSINESS LOGIC---------------------------------
// Start up a PHP Session for this user.
session_start();

$tgames = [];
$tname = $_REQUEST["name"] ?? "";
$trankno = $_REQUEST["rankno"] ?? - 1;
$tid = $_REQUEST["id"] ?? - 1;

// Handle our Requests and Search for Players using different methods
if (is_numeric($tid) && $tid > 0) {
    $tgame = jsonLoadOneGame($tid);
    $tgames[] = $tgame;
} else if (! empty($tname)) {
    // Filter the name
    $tname = appFormProcessData($tname);
    $tgamelist = jsonLoadAllGame();
} else if ($trankno > 0) {
    $tgamelist = jsonLoadAllGame();
    foreach ($tgamelist as $ts) {
        if ($tp->rankno === $trankno) {
            $tgames[] = $ts;
            break;
        }
    }
}

// Page Decision Logic - Have we found a player?
// Doesn't matter the route of finding them
if (count($tgames) === 0) {
    appGoToError();
} else {
    // We've found our player
    $tpagecontent = createPage($tgames);
    $tpagetitle = "Games Page";

    // ----BUILD OUR HTML PAGE----------------------------
    // Create an instance of our Page class
    $tpage = new MasterPage($tpagetitle);
    $tpage->setDynamic2($tpagecontent);
    $tpage->renderPage();
}
?>