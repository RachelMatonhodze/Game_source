<?php

class BLLGame
{

    // -------CLASS FIELDS------------------
    public $id = null;

    public $rankno;

    public $name;

    public $genre;

    public $availability;

    public $averageuserscore;

    public $reviewscore;

    public $reccomendations;

    public $gameprice;

    public $gamedevelopers;

    public $agerating;

    public $gameinformation;

    public $releasedate;

    public function fromArray(stdClass $passoc)
    {
        foreach ($passoc as $tkey => $tvalue) {
            $this->{$tkey} = $tvalue;
        }
    }
}

class BLLReview
{

    // -------CLASS FIELDS------------------
    public $id = null;

    public $heading;

    public $tagline;

    public $thumb_href;

    public $img_href;

    public $item_href;

    public $summary;

    public $content;

    public function fromArray(stdClass $passoc)
    {
        foreach ($passoc as $tkey => $tvalue) {
            $this->{$tkey} = $tvalue;
        }
    }
}

class BLLRanking
{

    // -------CLASS FIELDS------------------
    public $id = null;

    public $ranklist;

    public $captainindex;

    public $starplayerindex;

    public function fromArray(stdClass $passoc)
    {
        foreach ($passoc as $tkey => $tvalue) {
            $this->{$tkey} = $tvalue;
        }
    }
}

class BLLConsole
{

    // -------CLASS FIELDS------------------
    public $id = null;

    public $name;

    public $release;

    public $price;

    public $capacity;

    public $description;

    public function fromArray(stdClass $passoc)
    {
        foreach ($passoc as $tkey => $tvalue) {
            $this->{$tkey} = $tvalue;
        }
    }
}

?>