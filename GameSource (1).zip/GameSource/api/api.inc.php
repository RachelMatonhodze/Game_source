<?php
// Include our Internal Framework API Scripts
require_once ("fn_bll.inc.php"); // Functions - Business Logic Layer
require_once ("fn_pl.inc.php"); // Functions - Presentation Layer
require_once ("oo_page.inc.php"); // Objects - Page System - HTML Base
require_once ("oo_master.inc.php"); // Objects - Page System - Master Page
require_once ("oo_bll.inc.php"); // Objects - Business Logic Layer
require_once ("fn_dal.inc.php"); // Functions - Data Access Layer
require_once ("oo_pl.inc.php"); // Functions - Presentation Layer
?>