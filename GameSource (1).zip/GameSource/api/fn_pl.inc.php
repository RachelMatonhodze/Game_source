<?php
require_once ("oo_bll.inc.php");
require_once ("oo_pl.inc.php");

// ===========RENDER BUSINESS LOGIC OBJECTS=======================================================================

// ----------GAME REVIEW RENDERING------------------------------------------
function renderReviewItemAsSummary(BLLReview $partical)
{
    $treviewsrc = ! empty($partical->thumb_href) ? $partical->thumb_href : "blank-thumb.jpg";
    $treviewitem = <<<NI
    		    <section class="row details clearfix">
    		    <div class="media-left media-top">
    				<img src="img/reviews/{$treviewsrc}" width="256" />
    			</div>
    			<div class="media-body">
    				<h2>{$partical->heading}</h2>
    				
    				<div class="ni-summary">
    				<p>{$partical->summary}</p>
    				</div>
    				<a class="btn btn-xs btn-default" href="game.php?id={$partical->id}">More</a>
    	        </div>
    			</section>
    NI;
    return $treviewitem;
}

function renderReviewItemFull(BLLReview $particle)
{
    $treviewsrc = ! empty($particle->img_href) ? $particle->img_href : "blank-thumb.jpg";
    $treviewitem = <<<NI
    		    <section class="row details">
    		        <div class="well">
    		        <div class="media-left">
    				    <img src="img/reviews/{$treviewsrc}" />
    				</div>
    				<div class="media-body">
    				    <h1>{$particle->heading}</h1>
    				    <p id="news-tag">{$particle->tagline}</p>
    				    <p id="news-summ">{$particle->summary}</p>
    				    <p id="news-main">{$particle->content}</p>
    				</div>
    				</div>
    			</section>
    NI;
    return $treviewitem;
}

// ----------GAME RENDERING---------------------------------------
function renderGameTable(BLLRanking $prank)
{
    $trowdata = "";
    foreach ($prank->ranklist as $tp) {
        $tformat = $prank->captainindex == $tp->rankno ? " class=\"success\"" : "";
        if (empty($tformat))
            $tformat = $prank->starplayerindex == $tp->rankno ? " class=\"danger\"" : "";
        $trowdata .= <<<ROW
        <tr{$tformat}>
           <td>{$tp->rankno}</td>
           <td>{$tp->name}</td>
           <td>{$tp->genre}</td>
           <td>{$tp->averageuserscore}</td>
           <td>{$tp->reviewscore}</td>
           <td>{$tp->reccomendations}</td>
           
           <td><a class="btn btn-info" href="game.php?id={$tp->id}">More...</a></td>
        </tr>
        ROW;
    }
    $ttable = <<<TABLE
    <table class="table table-striped table-hover">
    	<thead>
    		<tr>
    			<th id="sort-rno">#</th>
    			<th id="sort-name">Name</th>
                <th id="sort-genre">Genre</th>
    			<th id="sort-aus">Average User Score</th>
                <th id="sort-revs">Personal Score: </th>
    			<th id="sort-rec">Reccomendations</th>
    			<th> </th>
    		</tr>
    	</thead>
    	<tbody>
    	{$trowdata}
    	</tbody>
    </table>
    TABLE;
    return $ttable;
}

function renderGameOverview(BLLGame $pp)
{
    $timgref = "img/games/{$pp->rankno}.jpg";
    $timg = file_exists($timgref) ? $timgref : "img/games/blank.jpg";
    $editorialrecom = file_get_contents("data/html/{$pp->id}.html");
    $toverview = <<<OV
        <article class="row marketing">
            <h2>Game Details</h2>
            <div class="media-left">
                <img src="$timg" width="256" />
            </div>
            <div class="media-body">
                <div class="well">
                    <h1>{$pp->name}</h1>
                </div>
                <h4>Genre: {$pp->genre}</h4>
                <h4>Release Date: {$pp->releasedate}</h4>
                <h4>Availability: {$pp->availability}</h4>
                <h4>Average User Score: {$pp->averageuserscore}</h4>
                <h4>Personal Score: {$pp->reviewscore}</h4>
                <h4>Reccomendations: {$pp->reccomendations}</h4>
                <h4>Game Price: {$pp->gameprice}</h4>
                <h4>Game Developers: {$pp->gamedevelopers}</h4>
                <h4>Age Rating: {$pp->agerating}</h4>
                <h4>Game Information {$pp->gameinformation}</h4>
            </div>
        <div class="card border-secondary mb-3">
    <div class="card-header">Editorial Review:</div>
    <div class="card-body">
    <p class="card-text">{$editorialrecom}</p>
    </div>
    </div>
            <div id="disqus_thread"></div>
    <script>
    /**
    * var disqus_config = function () {
    * this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
     this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
     };

    */ (function() { // DON'T EDIT BELOW THIS LINE
     var d = document, s = d.createElement('script');
      s.src = 'https://reviewgo-1.disqus.com/embed.js';
      s.setAttribute('data-timestamp', +new Date());
      (d.head || d.body).appendChild(s);
      })();
      </script>
      <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
      <script id="dsq-count-scr" src="//gamesource-1.disqus.com/count.js" async></script>
        </article>
      
    OV;
    return $toverview;
}

// ----------CONSOLE RENDERING--------------------------------------------
function renderConsoleSummary(BLLConsole $ps)
{
    $tshtml = <<<OVERVIEW
        <div class="well">
                <ul class="list-group">
                    <li class="list-group-item">
                        Console Name: <strong>{$ps->name}</strong>
                    </li>
                    <li class="list-group-item">
                        Release: <strong>{$ps->release}</strong>
                    </li>
                    <li class="list-group-item">
                        Price: <strong>{$ps->price}</strong>
                    </li>
                     <li class="list-group-item">
                         Capacity: <strong>{$ps->capacity}</strong>
                    </li>
                     <li class="list-group-item">
                         Description: <strong>{$ps->description}</strong>
                    </li>
                   
                </ul>
                <iframe width="560" height="315" src="https://www.youtube.com/embed/XE1mAkmWmsk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

        </div>
    OVERVIEW;
    return $tshtml;
}

// =============RENDER PRESENTATION LOGIC OBJECTS==================================================================
function renderUICarousel(array $pimgs, $pimgdir, $pid = "mycarousel")
{
    $tci = "";
    $count = 0;

    // -------Build the Images---------------------------------------------------------
    foreach ($pimgs as $titem) {
        $tactive = $count === 0 ? " active" : "";
        $thtml = <<<ITEM
                <div class="item{$tactive}">
                    <img class="img-responsive" src="{$pimgdir}/{$titem->img_href}">
                    <div class="container">
                        <div class="carousel-caption">
                            <h1>{$titem->title}</h1>
                            <p class="lead">{$titem->lead}</p>
        		        </div>
        			</div>
        	    </div>
        ITEM;
        $tci .= $thtml;
        $count ++;
    }

    // --Build Navigation-------------------------
    $tdot = "";
    $tdotset = "";
    $tarrows = "";

    if ($count > 1) {
        for ($i = 0; $i < count($pimgs); $i ++) {
            if ($i === 0)
                $tdot .= "<li data-target=\"#{$pid}\" data-slide-to=\"$i\" class=\"active\"></li>";
            else
                $tdot .= "<li data-target=\"#{$pid}\" data-slide-to=\"$i\"></li>";
        }
        $tdotset = <<<INDICATOR
                <ol class="carousel-indicators">
                {$tdot}
                </ol>
        INDICATOR;
    }
    if ($count > 1) {
        $tarrows = <<<ARROWS
        		<a class="left carousel-control" href="#{$pid}" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
        		<a class="right carousel-control" href="#{$pid}" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span></a>
        ARROWS;
    }

    $tcarousel = <<<CAROUSEL
        <div class="carousel slide" id="{$pid}">
                {$tdotset}
    			<div class="carousel-inner">
    				{$tci}
    			</div>
    		    {$tarrows}
        </div>
    CAROUSEL;
    return $tcarousel;
}

function renderUITabs(array $ptabs, $ptabid)
{
    $count = 0;
    $ttabnav = "";
    $ttabcontent = "";

    foreach ($ptabs as $ttab) {
        $tnavactive = "";
        $ttabactive = "";
        if ($count === 0) {
            $tnavactive = " class=\"active\"";
            $ttabactive = " active in";
        }
        $ttabnav .= "<li{$tnavactive}><a href=\"#{$ttab->tabid}\" data-toggle=\"tab\">{$ttab->tabname}</a></li>";
        $ttabcontent .= "<article class=\"tab-pane fade{$ttabactive}\" id=\"{$ttab->tabid}\">{$ttab->content}</article>";
        $count ++;
    }

    $ttabhtml = <<<HTML
            <ul class="nav nav-tabs">
            {$ttabnav}
            </ul>
        	<div class="tab-content" id="{$ptabid}">
    			  {$ttabcontent}
    		</div>
    HTML;
    return $ttabhtml;
}

function renderUIQuote(PLQuote $pquote)
{
    $tquote = <<<QUOTE
        <blockquote>
        {$pquote->quote}
        <small>{$pquote->person} in <cite title="{$pquote->source}">{$pquote->pub}</cite></small>
    	</blockquote>
    QUOTE;
    return $tquote;
}

function renderUIHomeArticle(PLHomeArticle $phome, $pwidth = 6)
{
    $thome = <<<HOME
        <article class="col-lg-{$pwidth}">
    		<h2>{$phome->heading}</h2>
    		<h4>
    			<span class="label label-success">{$phome->tagline}</span>
    		</h4>
    		<div class="home-thumb">
    			<img src="img/{$phome->storyimg_href}" />
    		</div>
    		<div>
    		  <strong>
    			{$phome->summary}
    		  </strong>
    		</div>
            <div>
    		    {$phome->content}
            </div>
            <div class="options details">
    			<a class="btn btn-info" href="{$phome->link}">{$phome->linktitle}</a>
            </div>
    	</article>
    HOME;
    return $thome;
}

function renderPagination($ppage, $pno, $pcurr)
{
    if ($pno <= 1)
        return "";

    $titems = "";
    $tld = $pcurr == 1 ? " class=\"disabled\"" : "";
    $trd = $pcurr == $pno ? " class=\"disabled\"" : "";

    $tprev = $pcurr - 1;
    $tnext = $pcurr + 1;

    $titems .= "<li$tld><a href=\"{$ppage}?page={$tprev}\">&laquo;</a></li>";
    for ($i = 1; $i <= $pno; $i ++) {
        $ta = $pcurr == $i ? " class=\"active\"" : "";
        $titems .= "<li$ta><a href=\"{$ppage}?page={$i}\">{$i}</a></li>";
    }
    $titems .= "<li$trd><a href=\"${ppage}?page={$tnext}\">&raquo;</a></li>";

    $tmarkup = <<<NAV
        <ul class="pagination pagination-sm">
            {$titems}
        </ul>
    NAV;
    return $tmarkup;
}

