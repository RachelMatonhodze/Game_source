<?php

// Include our HTML Page Class
require_once ("oo_page.inc.php");

class MasterPage
{

    // -------FIELD MEMBERS----------------------------------------
    private $_htmlpage;

    // Holds our Custom Instance of an HTML Page
    private $_dynamic_1;

    // Field Representing our Dynamic Content #1
    private $_dynamic_2;

    // Field Representing our Dynamic Content #2
    private $_dynamic_3;

    // Field Representing our Dynamic Content #3
    private $_game_ids;

    // -------CONSTRUCTORS-----------------------------------------
    function __construct($ptitle)
    {
        $this->_htmlpage = new HTMLPage($ptitle);
        $this->setPageDefaults();
        $this->setDynamicDefaults();
        $this->_game_ids = [
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10
        ];
    }

    // -------GETTER/SETTER FUNCTIONS------------------------------
    public function getDynamic1()
    {
        return $this->_dynamic_1;
    }

    public function getDynamic2()
    {
        return $this->_dynamic_2;
    }

    public function getDynamic3()
    {
        return $this->_dynamic_3;
    }

    public function setDynamic1($thtml)
    {
        $this->_dynamic_1 = $thtml;
    }

    public function setDynamic2($thtml)
    {
        $this->_dynamic_2 = $thtml;
    }

    public function setDynamic3($thtml)
    {
        $this->_dynamic_3 = $thtml;
    }

    public function getPage(): HTMLPage
    {
        return $this->_htmlpage;
    }

    // -------PUBLIC FUNCTIONS-------------------------------------
    public function createPage()
    {
        // Create our Dynamic Injected Master Page
        $this->setMasterContent();
        // Return the HTML Page..
        return $this->_htmlpage->createPage();
    }

    public function renderPage()
    {
        // Create our Dynamic Injected Master Page
        $this->setMasterContent();
        // Echo the page immediately.
        $this->_htmlpage->renderPage();
    }

    public function addCSSFile($tcssfile)
    {
        $this->_htmlpage->addCSSFile($tcssfile);
    }

    public function addScriptFile($tjsfile)
    {
        $this->_htmlpage->addScriptFile($tjsfile);
    }

    // -------PRIVATE FUNCTIONS-----------------------------------
    private function setPageDefaults()
    {
        $this->_htmlpage->setMediaDirectory("css", "js", "fonts", "img", "data");
        $this->addCSSFile("bootstrap.css");
        $this->addCSSFile("site.css");
        $this->addScriptFile("jquery-2.2.4.js");
        $this->addScriptFile("bootstrap.js");
        $this->addScriptFile("holder.js");
    }

    private function setDynamicDefaults()
    {
        $tcurryear = date("Y");
        // Set the Three Dynamic Points to Empty By Default.
        $this->_dynamic_1 = <<<JUMBO
        <h1>Quality Game Reviews</h1>

        JUMBO;
        $this->_dynamic_2 = "";
        $this->_dynamic_3 = <<<FOOTER
        <p>Rachel Matonhodze - LJMU &copy; {$tcurryear}</p>
        FOOTER;
    }

    private function setMasterContent()
    {
        $tid = $this->_game_ids[array_rand($this->_game_ids, 1)];
        $tmasterpage = <<<MASTER
        <div class="container">
        	<div class="header clearfix">
        		<nav>
        		   
        			<ul class="nav nav-pills pull-right">
                        <li role="presentation"><a href="index.php">Home Page</a></li>                      
        				<li role="presentation"><a href="console.php">Game Console</a></li>
        				<li role="presentation"><a href="ranking.php">Ranking</a></li>
                        <li role="presentation"><a href="review.php">Reviews</a></li>
        				<li role="presentation"><a href="game.php?id={$tid}">Random Game Review</a></li>
                        
        			</ul>
                    
                    <h1><img src="img/master/gamesource.jpg" alt="logo"/> </h1>
                   
        			
                   
        		</nav>
        	</div>
        	<div class="jumbotron">
        		{$this->_dynamic_1}
            </div>
        	<div class="row details">
        		{$this->_dynamic_2}
            </div>
            <footer class="footer">
        		{$this->_dynamic_3}
        	</footer>
        </div>        
        MASTER;
        $this->_htmlpage->setBodyContent($tmasterpage);
    }
}

?>