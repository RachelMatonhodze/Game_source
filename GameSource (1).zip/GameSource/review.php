<?php
// ----INCLUDE APIS------------------------------------
include ("api/api.inc.php");

// ----PAGE GENERATION LOGIC---------------------------
function createNewsItemPage(BLLReview $particle)
{
    $treviewg = renderReviewItemFull($particle);
    $tinfo = <<<PAGE
    <div class="details">
    {$treviewg}
    </div>
    PAGE;
    return $tinfo;
}

function createNewsSummaryPage()
{
    $tninfo = jsonLoadAllReviewItems();
    // Create the News Items for Article 2.
    $treviews = "";
    foreach ($tninfo as $tpi) {
        $treviews .= renderReviewItemAsSummary($tpi);
    }

    $tinfo = <<<PAGE
    <h2>Reviews</h2>
    <div class="details">
   
    {$treviews}
    </div>
    PAGE;
    return $tinfo;
}

// ----BUSINESS LOGIC---------------------------------
// Start up a PHP Session for this user.
session_start();

$tpagecontent = "";

$tid = $_REQUEST["gameid"] ?? - 1;
// Handle our Requests and find a specific news story and display it
if (is_numeric($tid) && $tid > 0) {
    $tfeature = jsonLoadOneReviewItem($tid);
    $tpagecontent = createNewsItemPage($tfeature);
} // In this case, we want to display a summary of all news stories
else {
    $tpagecontent = createNewsSummaryPage();
}

// Build up our Dynamic Content Items.
$tpagetitle = "Game Reviews";
$tpagelead = "";
$tpagefooter = "";

// ----BUILD OUR HTML PAGE----------------------------
// Create an instance of our Page class
$tpage = new MasterPage($tpagetitle);
// Set the Three Dynamic Areas (1 and 3 have defaults)
if (! empty($tpagelead))
    $tpage->setDynamic1($tpagelead);
$tpage->setDynamic2($tpagecontent);
if (! empty($tpagefooter))
    $tpage->setDynamic3($tpagefooter);
// Return the Dynamic Page to the user.
$tpage->renderPage();
?>